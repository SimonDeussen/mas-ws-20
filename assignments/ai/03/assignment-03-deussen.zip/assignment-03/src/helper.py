#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  3 01:36:01 2018

@author: Iswariya Manivannan
"""

import sys
import os
import time
from typing import List, NamedTuple, Callable, Dict
from enum import Enum
from collections import deque
from abc import abstractmethod
from time import sleep

Point = NamedTuple("Point", x=int, y=int)


class TileType(Enum):
    GOAL = 'goal'
    HORIZONTAL_WALL = 'horizontal_wall'
    VERTICAL_WALL = 'vertical_wall'
    START = 'start'
    EMPTY = 'empty'


class TileSymbol(Enum):
    EMPTY = ' '
    HORIZONTAL_WALL = '='
    VERTICAL_WALL = '|'
    START = 's'
    GOAL = '*'
    CROSSING = '\u253c'
    VERTICAL_MOVE = "\u2502"
    HORIZONTAL_MOVE = "\u2500"
    T_FLIP = "\u2534"
    T_NORMAL = "\u252C"
    T_RIGHT = "\u251C"
    T_LEFT = "\u2524"
    LEFT_BOTTOM = "\u2510"
    TOP_RIGHT = "\u2514"
    LEFT_TOP = "\u2518"
    BOTTOM_RIGHT = "\u250C"
    L_STOP = "\u2574"
    B_STOP = "\u2577"


class Node:
    """Basic class for represanting the tiles of map once parsed"""

    def __init__(self, *,
                 tile_type: TileType,
                 tile_symbol: TileSymbol,
                 x_pos: int,
                 y_pos: int):

        self.tile_type = tile_type
        self.tile_symbol = tile_symbol
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.children = None

    @staticmethod
    def from_tile(*, x_pos: int, y_pos: int, tile_symbol: str):
        """Creates node from position in maze map.
        Takes care of parsing the symbol string into a proper tile type

        Args:
            x_pos (int)
            y_pos (int)
            tile_symbol (str): String of tile in maze map.

        Raises:
            Exception: Raises exception in case of weird strings in tile_symbol

        Returns:
            [type]: Returns Node
        """
        tile_types = {
            TileSymbol.EMPTY.value: TileType.EMPTY.value,
            TileSymbol.HORIZONTAL_WALL.value: TileType.HORIZONTAL_WALL.value,
            TileSymbol.VERTICAL_WALL.value: TileType.VERTICAL_WALL.value,
            TileSymbol.START.value: TileType.START.value,
            TileSymbol.GOAL.value: TileType.GOAL.value
        }
        if tile_symbol not in tile_types:
            raise Exception(f"Weird tile symbol: {tile_symbol}")

        return Node(
            tile_type=tile_types[tile_symbol],
            tile_symbol=tile_symbol,
            x_pos=x_pos, y_pos=y_pos)

    def set_children(self, children) -> None:
        self.children = children

    def __repr__(self) -> str:
        return f'Node({self.tile_type}, {self.x_pos}, {self.y_pos})'

    def get_key(self):
        return f"{self.x_pos}-{self.y_pos}"

    def __sub__(self, other):
        return (self.x_pos-other.x_pos, self.y_pos-other.y_pos)


class Searcher:
    """Base class with common functions for the concrete implementations of the search algorithms. """

    def __init__(self, maze_map: List[List[str]], print_every_step: bool = False):
        self.maze_map = maze_map
        self.goals = self.get_goal_nodes(maze_map)
        self.start = self.get_start_node(maze_map)
        self.print_every_step = print_every_step
        self.walkable = [TileType.GOAL.value, TileType.EMPTY.value, TileType.START.value]

    @staticmethod
    def get_goal_nodes(maze_map: List[List[str]]) -> List[Node]:
        goals = []
        for y in range(len(maze_map)):
            for x in range(len(maze_map[y])):
                if maze_map[y][x] == TileSymbol.GOAL.value:
                    goals.append(Node.from_tile(x_pos=x, y_pos=y,
                                                tile_symbol=TileSymbol.GOAL.value))

        return goals

    @staticmethod
    def get_start_node(maze_map: List[List[str]]) -> Node:
        root = None
        for y in range(len(maze_map)):
            for x in range(len(maze_map[y])):
                if maze_map[y][x] == TileSymbol.START.value:
                    root = Node.from_tile(
                        x_pos=x, y_pos=y, tile_symbol=TileSymbol.START.value)
                    break
            if root:
                break
        else:
            raise Exception("No start found")

        return root

    def get_neighbor_nodes(self, node: Node) -> List[Node]:
        """Returns the upper, lower, right and left neighbour of given node.
        BTW this function implicitly defines the order in which neighnours are
        getting searched.

        Args:
            node (Node): Base node

        Returns:
            List[Node]: Up to four neighbours.
        """
        neighbors = []
        top = Point(node.x_pos, node.y_pos - 1)
        bottom = Point(node.x_pos, node.y_pos + 1)
        right = Point(node.x_pos + 1, node.y_pos)
        left = Point(node.x_pos - 1, node.y_pos)

        if top.y >= 0:
            neighbors.append(Node.from_tile(
                x_pos=top.x, y_pos=top.y, tile_symbol=self.maze_map[top.y][top.x]))

        if bottom.y < len(self.maze_map):
            neighbors.append(Node.from_tile(
                x_pos=bottom.x, y_pos=bottom.y, tile_symbol=self.maze_map[bottom.y][bottom.x]))

        if right.x < len(self.maze_map[node.y_pos]):
            neighbors.append(Node.from_tile(
                x_pos=right.x, y_pos=right.y, tile_symbol=self.maze_map[right.y][right.x]))

        if left.x >= 0:
            neighbors.append(Node.from_tile(
                x_pos=left.x, y_pos=left.y, tile_symbol=self.maze_map[left.y][left.x]))

        return neighbors

    def print_maze_with_nodes(self, nodes: List[Node] = None):
        """Takes care of printing the maze with extra nodes on top.

        Args:
            nodes (List[Node]): [description]. Defaults to None.
        """

        if not nodes:
            return

        # This copy is needed otherwise the original maze would get edited WHICH NOBODY WANTS!!!!
        maze_copy = [list(line) for line in self.maze_map]

        right = (1, 0)
        left = (-1, 0)
        down = (0, 1)
        up = (0, -1)

        for i in range(len(nodes)):
            current_node = nodes[i]

            # in case of only having one node for visualizing only one step
            if len(nodes) == 1:
                maze_copy[current_node.y_pos][current_node.x_pos] = "X"
                break

            symbol = ' '
            # at start and end of nodes extra care is needed to get the correct symbol.
            if i == 0:
                previous_node = nodes[i]
                next_node = nodes[i+1]
            elif i+1 == len(nodes):
                previous_node = nodes[i-1]
                next_node = nodes[i]
            else:
                previous_node = nodes[i-1]
                next_node = nodes[i+1]

            # here the distance is getting calculated (Node implements __sub__)
            curr_prev = current_node-previous_node
            next_curr = next_node-current_node

            if (curr_prev == up and next_curr == up) or (curr_prev == down and next_curr == down):
                symbol = TileSymbol.VERTICAL_MOVE.value
            elif (curr_prev == left and next_curr == left) or (curr_prev == right and next_curr == right):
                symbol = TileSymbol.HORIZONTAL_MOVE.value
            elif (curr_prev == right and next_curr == down) or (curr_prev == up and next_curr == left):
                symbol = TileSymbol.LEFT_BOTTOM.value
            elif (curr_prev == down and next_curr == right) or (curr_prev == left and next_curr == up):
                symbol = TileSymbol.TOP_RIGHT.value
            elif (curr_prev == right and next_curr == up) or (curr_prev == down and next_curr == left):
                symbol = TileSymbol.LEFT_TOP.value
            elif (curr_prev == up and next_curr == right) or (curr_prev == left and next_curr == down):
                symbol = TileSymbol.BOTTOM_RIGHT.value

            maze_copy[current_node.y_pos][current_node.x_pos] = symbol

        for goal in self.goals:
            maze_copy[goal.y_pos][goal.x_pos] = "*"

        maze_copy[self.start.y_pos][self.start.x_pos] = "S"

        for line in maze_copy:
            current_line = list(line)
            print("".join(current_line))

    @abstractmethod
    def search_algorithm(self, start: Node, goal: Node) -> List[Node]:
        """This function will get implemented by the concrete search algorithms.

        Args:
            start (Node):
            goal (Node):

        Returns:
            List[Node]:
        """
        pass

    def search(self) -> List[List[Node]]:
        """This function is the entry point for the searching.
        It will find path from start to first goal, and then to the next goals if
        reachable.

        Returns:
            List[List[Node]]: List with taken paths.
        """

        return [self.search_algorithm(self.start, goal) for goal in self.goals]

    def backtrack(self, key_start: str, key_goal: str, previous_nodes: Dict[str, str],
                  explored_nodes: Dict[str, Node]) -> List[Node]:
        """Creates shortest path to goal by backtracking.

        Args:
            key_start (str) 
            key_goal (str)
            previous_nodes (Dict[str, str])
            explored_nodes (Dict[str, Node])

        Returns:
            List[Node]: Shortest path
        """
        current = key_goal
        path = []
        while current != key_start:
            path.append(current)
            current = previous_nodes[current]

        return [explored_nodes[key] for key in path]


class BreadthFirst(Searcher):
    """Implementation of Breadth First Graph Searching.

    Resources: 
        https://www.codespeedy.com/breadth-first-search-algorithm-in-python/
        https://www.youtube.com/watch?v=ZuHW4fS60pc
        https://algorithms.tutorialhorizon.com/breadth-first-search-bfs-in-2d-matrix-2d-array/
        """

    def search_algorithm(self, start: Node, goal: Node) -> List[Node]:
        queue = deque([start])

        explored_nodes = {}
        previous_nodes = {start.get_key(): start.get_key()}
        while queue:
            current_node = queue.pop()

            if self.print_every_step:
                self.print_maze_with_nodes([current_node])
                sleep(0.1)

            if current_node.x_pos == goal.x_pos and current_node.y_pos == goal.y_pos:
                explored_nodes[current_node.get_key()] = current_node
                return self.backtrack(
                    start.get_key(), current_node.get_key(), previous_nodes, explored_nodes)

            if current_node.get_key() not in explored_nodes:
                explored_nodes[current_node.get_key()] = current_node
                neighbors = self.get_neighbor_nodes(current_node)

                for neighbor in neighbors:
                    if neighbor.tile_type in self.walkable:
                        if neighbor.get_key() not in explored_nodes:
                            previous_nodes[neighbor.get_key(
                            )] = current_node.get_key()
                            # besides the backtracking, THIS IS THE MOST IMPORTANT DIFFERENCE TO DFS
                            queue.appendleft(neighbor)

        print(f"[{self.__class__.__name__}] No Path found for {goal}")


class DepthFirst(Searcher):
    """Implementation of Depth First Graph Search.

    Resources:
        https://www.codespeedy.com/depth-first-search-algorithm-in-python/
    """

    def search_algorithm(self, start: Node, goal: Node) -> List[Node]:
        queue = deque([start])

        explored_nodes = {}

        while queue:

            current_node = queue.pop()

            if self.print_every_step:
                self.print_maze_with_nodes([current_node])
                sleep(0.1)

            if current_node.x_pos == goal.x_pos and current_node.y_pos == goal.y_pos:
                path = [node for k, node in explored_nodes.items()]
                return path

            if current_node.get_key() not in explored_nodes:
                explored_nodes[current_node.get_key()] = current_node
                neighbors = self.get_neighbor_nodes(current_node)

                for neighbor in neighbors:
                    if neighbor.tile_type in self.walkable:
                        queue.append(neighbor)

        print(f"[{self.__class__.__name__}] No Path found for {goal}")


class IterativeDeepening(Searcher):
    """Implements the Iterative Deepening Graph Search.
    It introduces and depth limit in its Search Algorithm which is closely related
    to DFS and uses the same backtracking as bfs.

    Resources:
        https://www.geeksforgeeks.org/iterative-deepening-searchids-iterative-deepening-depth-first-searchiddfs/
    """

    def depth_limited(self, start: Node, goal: Node, max_depth: int) -> List[Node]:
        queue = deque([start])

        explored_nodes = {}
        dephts = {start.get_key(): 0}
        previous_nodes = {start.get_key(): start.get_key()}

        while queue:
            current_node = queue.pop()

            if self.print_every_step:
                self.print_maze_with_nodes([current_node])
                sleep(0.1)

            if current_node.x_pos == goal.x_pos and current_node.y_pos == goal.y_pos:
                explored_nodes[current_node.get_key()] = current_node
                return self.backtrack(
                    start.get_key(), current_node.get_key(), previous_nodes, explored_nodes)

            if current_node.get_key() not in explored_nodes:
                explored_nodes[current_node.get_key()] = current_node
                neighbors = self.get_neighbor_nodes(current_node)

                for neighbor in neighbors:
                    if neighbor.get_key() not in explored_nodes and neighbor.tile_type in self.walkable and dephts[
                            current_node.get_key()] < max_depth:
                        dephts[neighbor.get_key()] = dephts[current_node.get_key()] + 1
                        previous_nodes[neighbor.get_key()] = current_node.get_key()
                        queue.append(neighbor)

        return False

    def search_algorithm(self, start: Node, goal: Node) -> List[Node]:
        for i in range(20):
            depth = i**2
            result = self.depth_limited(start, goal, depth)
            if result:
                print(f"[{self.__class__.__name__}] Found Path for {goal} with depth: {depth}")
                return result

        else:
            print(f"[{self.__class__.__name__}] No Path found for {goal}")


def read_maze_map(path) -> List[List[str]]:
    with open(path) as f1:
        maze_map_map1 = f1.readlines()

    maze = []
    for line in maze_map_map1:
        line = line.replace("\n", "")
        maze.append(list(line))

    return maze
