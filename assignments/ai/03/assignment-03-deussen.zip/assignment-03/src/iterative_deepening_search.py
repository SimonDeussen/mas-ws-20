#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from time import sleep
from helper import *
import sys
import os
from collections import deque
from helper import *


def iterative_deepening_depth_first_search(maze_map):
    searcher = IterativeDeepening(maze_map)
    paths = searcher.search()

    for path in paths:
        searcher.print_maze_with_nodes(path)


if __name__ == '__main__':

    working_directory = os.path.dirname(os.path.realpath(__file__))

    maps = ['maps/map3.txt']  # , 'maps/map2.txt', 'maps/map3.txt']

    for map_name in maps:
        path_map = os.path.join(working_directory, map_name)
        maze_map = read_maze_map(path_map)
        iterative_deepening_depth_first_search(maze_map)
