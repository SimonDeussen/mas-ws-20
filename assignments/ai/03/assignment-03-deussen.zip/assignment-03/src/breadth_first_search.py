#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 21:15:04 2018

@author: Iswariya Manivannan
"""
import sys
import os
from collections import deque
from helper import *
from time import sleep


def breadth_first_search(maze_map):
    searcher = BreadthFirst(maze_map)
    paths = searcher.search()

    for path in paths:
        searcher.print_maze_with_nodes(path)


if __name__ == '__main__':

    working_directory = os.path.dirname(os.path.realpath(__file__))

    maps = ['maps/map1.txt', 'maps/map2.txt', 'maps/map3.txt']

    for map_name in maps:
        path_map = os.path.join(working_directory, map_name)
        maze_map = read_maze_map(path_map)
        breadth_first_search(maze_map)
