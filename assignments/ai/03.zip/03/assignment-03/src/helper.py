#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  3 01:36:01 2018

@author: Iswariya Manivannan
"""

import sys
import os
import time
from typing import List, NamedTuple, Callable
from enum import Enum
from collections import deque
from abc import abstractmethod
from time import sleep

Point = NamedTuple("Point", x=int, y=int)


class TileType(Enum):
    GOAL = 'goal'
    HORIZONTAL_WALL = 'horizontal_wall'
    VERTICAL_WALL = 'vertical_wall'
    START = 'start'
    EMPTY = 'empty'


class TileSymbol(Enum):
    EMPTY = ' '
    HORIZONTAL_WALL = '='
    VERTICAL_WALL = '|'
    START = 's'
    GOAL = '*'
    CROSSING = '\u253c'
    VERTICAL_MOVE = "\u2502"
    HORIZONTAL_MOVE = "\u2500"
    T_FLIP = "\u2534"
    T_NORMAL = "\u252C"
    T_RIGHT = "\u251C"
    T_LEFT = "\u2524"
    LEFT_BOTTOM = "\u2510"
    TOP_RIGHT = "\u2514"
    LEFT_TOP = "\u2518"
    BOTTOM_RIGHT = "\u250C"
    L_STOP = "\u2574"
    B_STOP = "\u2577"


class Node:
    def __init__(self, *,
                 tile_type: TileType,
                 tile_symbol: TileSymbol,
                 x_pos: int,
                 y_pos: int,
                 depth: int,
                 moveable: bool):

        self.tile_type = tile_type
        self.tile_symbol = tile_symbol
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.depth = depth
        self.children = None

    @staticmethod
    def from_tile(*, x_pos: int, y_pos: int, tile_symbol: str):
        tile_types = {
            TileSymbol.EMPTY.value: TileType.EMPTY.value,
            TileSymbol.HORIZONTAL_WALL.value: TileType.HORIZONTAL_WALL.value,
            TileSymbol.VERTICAL_WALL.value: TileType.VERTICAL_WALL.value,
            TileSymbol.START.value: TileType.START.value,
            TileSymbol.GOAL.value: TileType.GOAL.value
        }

        tile_type = tile_types[tile_symbol]

        if not tile_type:
            raise Exception(f"Weird tile symbol: {tile_symbol}")

        return Node(
            tile_type=tile_type,
            tile_symbol=tile_symbol,
            x_pos=x_pos, y_pos=y_pos, depth=0, moveable=False)

    def set_children(self, children) -> None:
        self.children = children

    def __repr__(self) -> str:
        return f'Node({self.tile_type}, {self.x_pos}, {self.y_pos})'

    def get_key(self):
        return f"{self.x_pos}-{self.y_pos}"

    def __sub__(self, other):
        return (self.x_pos-other.x_pos, self.y_pos-other.y_pos)


class Tree:
    def __init__(self, root: Node):
        self.root = root


class Searcher:
    def __init__(self, maze_map: List[List[str]]):
        self.maze_map = maze_map
        self.goals = self.get_goal_nodes(maze_map)
        self.start = self.get_start_node(maze_map)

    @staticmethod
    def get_goal_nodes(maze_map: List[List[str]]) -> List[Node]:
        goals = []
        for y in range(len(maze_map)):
            for x in range(len(maze_map[y])):
                if maze_map[y][x] == TileSymbol.GOAL.value:
                    goals.append(Node.from_tile(x_pos=x, y_pos=y,
                                                tile_symbol=TileSymbol.GOAL.value))

        print(f'found {len(goals)} goals')

        return goals

    @staticmethod
    def get_start_node(maze_map: List[List[str]]) -> Node:
        """Function to create a tree from the map file. The idea is
        to check for the possible movements from each position on the
        map and encode it in a data structure like list.

        Parameters
        ----------
        maze_map : [type]
            [description]

        Returns
        -------
        [type]
            [description]
        """
        root = None
        for y in range(len(maze_map)):
            for x in range(len(maze_map[y])):
                if maze_map[y][x] == TileSymbol.START.value:
                    root = Node.from_tile(
                        x_pos=x, y_pos=y, tile_symbol=TileSymbol.START.value)
                    break
            if root:
                break
        else:
            raise Exception("No start found")

        print(f'Found start node: {root}')
        return root

    def get_neighbor_nodes(self, node: Node) -> List[Node]:
        neighbors = []
        top = Point(node.x_pos, node.y_pos - 1)
        bottom = Point(node.x_pos, node.y_pos + 1)
        right = Point(node.x_pos + 1, node.y_pos)
        left = Point(node.x_pos - 1, node.y_pos)

        if top.y >= 0:
            # print(f"found top node {top.x},{top.y}")
            neighbors.append(Node.from_tile(
                x_pos=top.x, y_pos=top.y, tile_symbol=self.maze_map[top.y][top.x]))

        if bottom.y < len(self.maze_map):
            # print(f"found bottom node {bottom.x},{bottom.y}")

            neighbors.append(Node.from_tile(
                x_pos=bottom.x, y_pos=bottom.y, tile_symbol=self.maze_map[bottom.y][bottom.x]))

        if right.x < len(self.maze_map[node.y_pos]):
            # print(f"found right node {right.x},{right.y}")

            neighbors.append(Node.from_tile(
                x_pos=right.x, y_pos=right.y, tile_symbol=self.maze_map[right.y][right.x]))

        if left.x >= 0:
            # print(f"found left node {left.x},{left.y}")

            neighbors.append(Node.from_tile(
                x_pos=left.x, y_pos=left.y, tile_symbol=self.maze_map[left.y][left.x]))

        return neighbors

    def print_maze_with_nodes(self, nodes: Node = None):
        if not nodes:
            return
        maze_copy = [list(line) for line in self.maze_map]
        right = (1, 0)
        left = (-1, 0)
        down = (0, 1)
        up = (0, -1)

        for i in range(len(nodes)):
            current_node = nodes[i]

            if len(nodes) == 1:
                maze_copy[current_node.y_pos][current_node.x_pos] = "X"
                break

            symbol = ' '
            if i == 0:
                previous_node = nodes[i]
                next_node = nodes[i+1]
            elif i+1 == len(nodes):
                previous_node = nodes[i-1]
                next_node = nodes[i]
            else:
                previous_node = nodes[i-1]
                next_node = nodes[i+1]

            curr_prev = current_node-previous_node
            next_curr = next_node-current_node

            if (curr_prev == up and next_curr == up) or (curr_prev == down and next_curr == down):
                symbol = TileSymbol.VERTICAL_MOVE.value
            elif (curr_prev == left and next_curr == left) or (curr_prev == right and next_curr == right):
                symbol = TileSymbol.HORIZONTAL_MOVE.value
            elif (curr_prev == right and next_curr == down) or (curr_prev == up and next_curr == left):
                symbol = TileSymbol.LEFT_BOTTOM.value
            elif (curr_prev == down and next_curr == right) or (curr_prev == left and next_curr == up):
                symbol = TileSymbol.TOP_RIGHT.value
            elif (curr_prev == right and next_curr == up) or (curr_prev == down and next_curr == left):
                symbol = TileSymbol.LEFT_TOP.value
            elif (curr_prev == up and next_curr == right) or (curr_prev == left and next_curr == down):
                symbol = TileSymbol.BOTTOM_RIGHT.value
            else:
                symbol = 'X'

            maze_copy[current_node.y_pos][current_node.x_pos] = symbol

        for line in maze_copy:
            current_line = list(line)
            print("".join(current_line))

    @abstractmethod
    def search_algorithm(self, start: Node, goal: Node) -> List[Node]:
        pass

    def search(self):
        paths = []

        for i in range(1):  # len(self.goals)):
            if i == 0:
                paths.append(self.search_algorithm(self.start,
                                                   self.goals[i]))
            else:
                paths.append(self.search_algorithm(self.goals[i-1],
                                                   self.goals[i]))
            print(f'found {i} path')

        return paths


class BreadthFirst(Searcher):
    def search_algorithm(self, start: Node, goal: Node) -> List[Node]:
        queue = deque([start])

        explored_nodes = {}

        while queue:
            current_node = queue.pop()
            visited = [node for k, node in explored_nodes.items()]
            self.print_maze_with_nodes(visited)
            sleep(0.03)

            if current_node.x_pos == goal.x_pos and current_node.y_pos == goal.y_pos:
                path = [node for k, node in explored_nodes.items()]
                return path

            if current_node.get_key() not in explored_nodes:
                explored_nodes[current_node.get_key()] = current_node
                neighbors = self.get_neighbor_nodes(current_node)
                for neighbor in neighbors:
                    if neighbor.tile_type in [TileType.GOAL.value, TileType.EMPTY.value, TileType.START.value]:
                        queue.appendleft(neighbor)

        print(f"No Path found for {goal}")


class DepthFirst(Searcher):

    def search_algorithm(self, start: Node, goal: Node) -> List[Node]:
        queue = deque([start])

        explored_nodes = {}

        while queue:
            current_node = queue.pop()

            self.print_maze_with_nodes([current_node])

            if current_node.x_pos == goal.x_pos and current_node.y_pos == goal.y_pos:
                path = [node for k, node in explored_nodes.items()]
                return path

            if current_node.get_key() not in explored_nodes:
                explored_nodes[current_node.get_key()] = current_node
                neighbors = self.get_neighbor_nodes(current_node)

                for neighbor in neighbors:
                    if neighbor.tile_type in [TileType.GOAL.value, TileType.EMPTY.value, TileType.START.value]:
                        queue.append(neighbor)

        print(f"No Path found for {goal}")


def assign_character_for_nodes(maze_map, current_node, prev_node):
    """Function to assign character for the visited nodes. Please assign
    meaningful characters based on the direction of tree traversal.

    Parameters
    ----------
    maze_map : [type]
        [description]
    current_node : [type]
        [description]
    prev_node : [type]
        [description]

    Returns
    -------
    [type]
        [description]
    """

    raise NotImplementedError


def read_maze_map(path) -> List[List[str]]:
    with open(path) as f1:
        maze_map_map1 = f1.readlines()

    maze = []
    for line in maze_map_map1:
        line = line.replace("\n", "")
        maze.append(list(line))

    return maze


def write_to_file(file_name, path):
    """Function to write output to console and the optimal path
    from start to each goal to txt file.
    Please ensure that it should ALSO be possible to visualize each and every
    step of the tree traversal algorithm in the map in the console.
    This enables understanding towards the working of your
    tree traversal algorithm as to how it reaches the goals.

    Parameters
    ----------
    filen_name : string
        This parameter defines the name of the txt file.
    path : [type]
        [description]

    """

    raise NotImplementedError
