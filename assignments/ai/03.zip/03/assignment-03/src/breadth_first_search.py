#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 27 21:15:04 2018

@author: Iswariya Manivannan
"""
import sys
import os
from collections import deque
from helper import *
from time import sleep


def breadth_first_search(maze_map):
    """Function to implement the BFS algorithm.
    Please use the functions in helper.py to complete the algorithm.
    Please do not clutter the code this file by adding extra functions.
    Additional functions if required should be added in helper.py

    Parameters
    ----------
    maze_map : [type]
        [description]
    start_pos : [type]
        [description]
    goal_pos : [type]
        [description]

    Returns
    -------
    [type]
        [description]
    """
    searcher = BreadthFirst(maze_map)
    paths = searcher.search()

    for path in paths:
        searcher.print_maze_with_nodes(path)


if __name__ == '__main__':

    working_directory = os.getcwd()

    path = "/home/sd/Documents/code/mas-ws-20/assignments/ai/03/assignment-03/src/maps"
    maps = ['map1.txt']  # , 'map2.txt', 'map3.txt']

    for map_name in maps:
        path_map = os.path.join(path, map_name)
        maze_map = read_maze_map(path_map)
        breadth_first_search(maze_map)

    # write_to_file("bfs_map1", path_map1)

    # path_map2 = breadth_first_search(maze_map_map2, start_pos_map2, goal_pos_map2)
    # write_to_file("bfs_map2", path_map2)

    # path_map3 = breadth_first_search(maze_map_map3, start_pos_map3, goal_pos_map3)
    # write_to_file("bfs_map3", path_map3)
